create definer = root@localhost trigger del1
    before delete
    on student
    for each row
    delete from book_manage.borrow where sid = old.sid;

