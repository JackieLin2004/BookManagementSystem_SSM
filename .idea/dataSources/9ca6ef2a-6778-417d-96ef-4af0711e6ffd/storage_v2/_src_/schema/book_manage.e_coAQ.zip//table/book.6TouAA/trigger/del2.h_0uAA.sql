create definer = root@localhost trigger del2
    before delete
    on book
    for each row
    delete from book_manage.borrow where bid = old.bid;

